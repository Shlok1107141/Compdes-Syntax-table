DenseSym manuscript, Draft 2 (Review 2), LaTeX source
=====================================================

Overleaf:  New Project -> Upload Project -> choose this zip. The compiler is pdfLaTeX
           (Overleaf's default) and the main document is main.tex.
Locally:   latexmk -pdf main.tex     (any TeX Live 2022 or newer)

Contents:  main.tex       the whole paper (IEEE Access layout, standard packages only)
           figures/       every image the paper uses: charts, screenshots, logos, photos

The numbers in the paper come from the repository's scripts; see results/README.md in
https://github.com/Shlok1107141/Compdes-Syntax-table
